//logout 
$('#logout').click(function(){
		window.location	= "user/logout";
	});

//product categories
$('#prod_category').click(function(){
    window.location = "category/";
  });
//products
$('#products').click(function(){
    window.location = "products/";
  });

//customer
$('#customer').click(function(){
    window.location = "customer/";
  });
