<?php $this->load->view('admin/components/page_head'); ?>
<?php $this->load->view('admin/dashboard'); ?>
<?php $this->load->view('admin/components/page_tail'); ?>