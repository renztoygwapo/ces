<body class="page-header-fixed page-quick-sidebar-over-content">
<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-default">
  <!-- BEGIN HEADER INNER -->
  <div class="page-header-inner">
    <!-- BEGIN LOGO -->
    <div class="page-logo">
      <?php echo anchor('admin/dashboard','MEGA GAS','class="logo" '); ?>
    </div>
  
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>