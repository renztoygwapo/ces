<?php $this->load->view('admin/components/frontpage_head'); ?>
<div class="container"><h1>I am Events Page!</h1>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam sit nonummy nibh 
Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam sit nonummy nibh euismod tincidunt ut laoreet dolore magna aliquarm erat sit volutpat.
euismod tincidunt ut laoreet dolore magna aliquarm erat sit volutpat.</p>  
</div> 

<?php $this->load->view('admin/components/frontpage_tail'); ?>