<?php $this->load->view('admin/components/page_head_admin_login'); ?>
		
<?php $this->load->view($subview); // Subview is set in controller ?>

<?php $this->load->view('admin/components/page_tail'); ?>