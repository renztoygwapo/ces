<?php $this->load->view('admin/components/frontpage_head'); ?>
<div class="container"><h1>I am About Us Page!</h1></div>   
<?php $this->load->view('admin/components/frontpage_tail'); ?>