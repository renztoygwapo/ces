<?php $this->load->view('admin/components/frontpage_head'); ?>
<?php $this->load->view('admin/index'); ?>
<?php $this->load->view('admin/components/frontpage_tail'); ?>