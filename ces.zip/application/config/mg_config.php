<?php
$config['site_name'] = 'Carmen Elementary School';